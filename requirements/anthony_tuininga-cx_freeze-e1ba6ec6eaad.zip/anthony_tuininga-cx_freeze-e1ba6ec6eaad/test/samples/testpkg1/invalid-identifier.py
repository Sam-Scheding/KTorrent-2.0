# Since this is a python module, we try to import it even though its name is not
# a valid identifier (required for e.g. win32com.gen_py.*)
