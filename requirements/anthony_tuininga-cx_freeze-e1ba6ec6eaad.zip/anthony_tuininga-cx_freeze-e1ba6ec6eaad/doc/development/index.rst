
Developing cx_Freeze
====================

The source code can be found `on Bitbucket <https://bitbucket.org/anthony_tuininga/cx_freeze/src>`_.

Downloads and issue tracking are `on Sourceforge <http://sourceforge.net/projects/cx-freeze/>`_.

Contents:

.. toctree::
   :maxdepth: 2
   
   code_layout.rst
